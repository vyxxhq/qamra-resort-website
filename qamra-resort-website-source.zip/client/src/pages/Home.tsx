import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Wifi, Waves, Home as HomeIcon, Users, Camera } from "lucide-react";
import { useState } from "react";

/**
 * Qamra Chalets & Resort - Luxury Resort Website
 * Design Philosophy: Luxury Minimalism with Warmth
 * - Clean, elegant layouts with purposeful whitespace
 * - Warm color palette (sand tones + deep ocean blue)
 * - Playfair Display for headings, Inter for body
 * - Smooth animations and hover effects
 */

export default function HomePage() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const testimonials = [
    {
      name: "AMMARA IRFAN",
      text: "Love the interior. Such a beautiful and well decorated villa. Amazing experience",
    },
    {
      name: "Nebil Aman",
      text: "Very clean n hospitality n price to compare other cheaper",
    },
    {
      name: "Obaid Haq",
      text: "Nice for weddings",
    },
    {
      name: "Nani Jamae",
      text: "May God bless you, firstly as the owner or manager of the place… honestly, you are very kind… your style and dealings are very refined. The place is spacious and you pay great attention to cleanliness… thank you",
    },
    {
      name: "فوز الغامدي",
      text: "The rest area was very beautiful, spacious, and clean",
    },
    {
      name: "مها باجمال",
      text: "The owner of the chalet is incredibly kind, ethical, and helpful... his service was top-notch.",
    },
    {
      name: "Sara Fi",
      text: "The place is spacious, clean, and very beautiful. The chalet is absolutely lovely; I highly recommend it.",
    },
    {
      name: "abody alhammad",
      text: "The chalet is very beautiful, tidy and clean. It consists of three adjacent chalets that can be taken together or one by one...",
    },
    {
      name: "Salah Omer",
      text: "A wonderful, clean, tidy, and quiet place with a beautiful rooftop view",
    },
    {
      name: "فتون الوادي محمد",
      text: "Qamra Resort is truly one of the most amazing places... It's a truly wonderful retreat and resort; you'll never regret it.",
    },
  ];

  const amenities = [
    { icon: Waves, title: "Swimming Pools", description: "Crystal clear pools for relaxation and recreation" },
    { icon: Wifi, title: "Air Conditioning", description: "Climate control in all chalets for comfort" },
    { icon: Users, title: "Spacious Lounges", description: "Large gathering areas for families and groups" },
    { icon: Camera, title: "Outdoor Areas", description: "Beautiful landscaped outdoor spaces" },
    { icon: HomeIcon, title: "Rooftop Views", description: "Panoramic views of Jeddah skyline" },
    { icon: MapPin, title: "Prime Location", description: "Well-maintained and easily accessible" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm z-50 shadow-sm">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-primary">Qamra Resort</div>
          <div className="hidden md:flex gap-8">
            <a href="#about" className="text-sm hover:text-primary transition-colors">About</a>
            <a href="#amenities" className="text-sm hover:text-primary transition-colors">Amenities</a>
            <a href="#testimonials" className="text-sm hover:text-primary transition-colors">Reviews</a>
            <a href="#contact" className="text-sm hover:text-primary transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 relative h-screen flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663638170580/icvNx97D7kL2SG7kRBozob/hero-resort-jeddah-LDzzHzABuerGbmyGjafhZ8.webp')",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent"></div>
        </div>

        <div className="relative z-10 container max-w-6xl mx-auto px-4 text-white">
          <div className="max-w-2xl">
            <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
              Qamra Chalets & Resort
            </h1>
            <p className="text-xl md:text-2xl mb-8 font-light">
              Experience luxury and tranquility in the heart of Jeddah
            </p>
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white"
              onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            >
              Get in Touch
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-5xl font-bold mb-12 text-center">About Our Resort</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663638170580/icvNx97D7kL2SG7kRBozob/chalet-interior-5jieti3bK3rTnk4uryyoC8.webp"
                alt="Chalet Interior"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <p className="text-lg text-gray-700">
                Welcome to Qamra Chalets & Resort, your premier destination for luxury accommodations in Jeddah, Saudi Arabia. Our resort features spacious, clean, and beautifully designed chalets that combine modern comfort with elegant aesthetics.
              </p>
              <p className="text-lg text-gray-700">
                Whether you're planning a family getaway, a romantic escape, or a special celebration, our resort provides the perfect setting. Each chalet is meticulously maintained and equipped with premium amenities to ensure your stay is unforgettable.
              </p>
              <p className="text-lg text-gray-700">
                From intimate family gatherings to grand weddings and corporate events, Qamra Resort is your ideal choice for creating lasting memories in a luxurious environment.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Amenities Section */}
      <section id="amenities" className="py-20 bg-secondary/5">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-5xl font-bold mb-12 text-center">Premium Amenities</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {amenities.map((amenity, index) => {
              const Icon = amenity.icon;
              return (
                <div
                  key={index}
                  className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 transform hover:scale-105"
                >
                  <Icon className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-3">{amenity.title}</h3>
                  <p className="text-gray-600">{amenity.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Gallery Section */}
      <section className="py-20 bg-white">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-5xl font-bold mb-12 text-center">Experience Luxury</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663638170580/icvNx97D7kL2SG7kRBozob/amenities-pool-SdkFcWTqvQprE9pjYedDMa.webp"
                alt="Swimming Pool"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                <p className="text-white text-2xl font-bold p-6">Pristine Swimming Pools</p>
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663638170580/icvNx97D7kL2SG7kRBozob/rooftop-view-Qh4k5qpCa2DUFNAxEheizV.webp"
                alt="Rooftop View"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                <p className="text-white text-2xl font-bold p-6">Breathtaking Rooftop Views</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-secondary/5">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-5xl font-bold mb-12 text-center">Guest Reviews</h2>
          <div className="bg-white p-12 rounded-lg shadow-lg">
            <div className="mb-8">
              <p className="text-2xl text-gray-800 mb-6 italic">
                "{testimonials[activeTestimonial].text}"
              </p>
              <p className="text-lg font-semibold text-primary">
                — {testimonials[activeTestimonial].name}
              </p>
            </div>

            {/* Testimonial Navigation */}
            <div className="flex justify-center gap-4 mt-8">
              <Button
                variant="outline"
                onClick={() => setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)}
              >
                Previous
              </Button>
              <div className="flex items-center gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveTestimonial(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === activeTestimonial ? "bg-primary w-8" : "bg-gray-300"
                    }`}
                  />
                ))}
              </div>
              <Button
                variant="outline"
                onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section className="py-20 bg-white">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-5xl font-bold mb-12 text-center">Perfect for Every Occasion</h2>
          <div className="relative h-96 rounded-lg overflow-hidden shadow-lg mb-8">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663638170580/icvNx97D7kL2SG7kRBozob/wedding-venue-LqMnQgV8P9oMxX8wPcwi98.webp"
              alt="Wedding Venue"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-3">Family Gatherings</h3>
              <p className="text-gray-600">Create beautiful memories with your loved ones in our spacious chalets</p>
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-3">Weddings</h3>
              <p className="text-gray-600">Celebrate your special day in an elegant and luxurious setting</p>
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-3">Corporate Events</h3>
              <p className="text-gray-600">Host your business gatherings and celebrations with style</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-secondary/5">
        <div className="container max-w-6xl mx-auto px-4">
          <h2 className="text-5xl font-bold mb-12 text-center">Get in Touch</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold mb-4">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold">Location</p>
                      <p className="text-gray-600">Jeddah, Saudi Arabia</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Phone className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold">Phone</p>
                      <p className="text-gray-600">Available upon request</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Mail className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold">Email</p>
                      <p className="text-gray-600">Contact us for more information</p>
                    </div>
                  </div>
                </div>
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                Book Now
              </Button>
            </div>

            <div className="rounded-lg overflow-hidden shadow-lg h-96">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3574.8534267659647!2d39.1759!3d21.5383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c21a4c3d3d3d3d%3A0x3d3d3d3d3d3d3d3d!2sQamra%20Chalets%20%26%20Resort!5e0!3m2!1sen!2ssa!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-8">
        <div className="container max-w-6xl mx-auto px-4 text-center">
          <p>&copy; 2026 Qamra Chalets & Resort. All rights reserved.</p>
          <p className="text-sm text-gray-400 mt-2">Luxury Chalets in Jeddah, Saudi Arabia</p>
        </div>
      </footer>
    </div>
  );
}
